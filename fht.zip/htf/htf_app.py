import os
import random
import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserIconView
from kivy.core.window import Window
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.properties import StringProperty, ObjectProperty, ListProperty, NumericProperty
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.lang import Builder

# Set window size for mobile phone
Window.size = (360, 640)

# Create images directory if it doesn't exist
if not os.path.exists('images'):
    os.makedirs('images')

# Create sample product images directory
if not os.path.exists('images/products'):
    os.makedirs('images/products')

# Create sample profile images directory
if not os.path.exists('images/profiles'):
    os.makedirs('images/profiles')

# Generate sample product images (in a real app, you would use actual images)
sample_products = [
    "Organic Tomatoes", "Fresh Carrots", "Wheat Grains", "Basmati Rice", 
    "Apples", "Mangoes", "Potatoes", "Onions", "Garlic", "Cabbage",
    "Cauliflower", "Spinach", "Bananas", "Oranges", "Grapes"
]

for i, product in enumerate(sample_products):
    # Create empty image files for demo
    with open(f'images/products/{product.replace(" ", "_").lower()}.png', 'w') as f:
        f.write('')

# Generate sample profile images
sample_users = ["Rajesh Kumar", "Priya Sharma", "Vikram Singh", "Anjali Patel"]
for user in sample_users:
    with open(f'images/profiles/{user.replace(" ", "_").lower()}.png', 'w') as f:
        f.write('')

# Main app structure
Builder.load_string('''
<CustomButton@Button>:
    background_normal: ''
    background_color: (0, 0, 0, 0)
    canvas.before:
        Color:
            rgba: (0.2, 0.7, 0.3, 1) if self.state == 'normal' else (0.15, 0.6, 0.25, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12),]

<RoleSelectionScreen>:
    FloatLayout:
        canvas:
            Color:
                rgba: (0.9, 0.95, 0.9, 1)
            Rectangle:
                pos: self.pos
                size: self.size
        
        Image:
            source: 'data/logo.png'  # Replace with your logo
            size_hint: None, None
            size: dp(120), dp(120)
            pos_hint: {'center_x': 0.5, 'center_y': 0.7}
        
        Label:
            text: 'Help The Farmers'
            font_size: sp(28)
            bold: True
            color: (0.2, 0.4, 0.2, 1)
            pos_hint: {'center_x': 0.5, 'center_y': 0.55}
        
        Label:
            text: 'Empowering Farmers, Connecting Buyers'
            font_size: sp(16)
            color: (0.3, 0.3, 0.3, 1)
            pos_hint: {'center_x': 0.5, 'center_y': 0.48}
        
        CustomButton:
            text: 'I am a Farmer'
            size_hint: 0.8, None
            height: dp(50)
            pos_hint: {'center_x': 0.5, 'center_y': 0.35}
            on_press: root.select_role('farmer')
        
        CustomButton:
            text: 'I am a Buyer'
            size_hint: 0.8, None
            height: dp(50)
            pos_hint: {'center_x': 0.5, 'center_y': 0.25}
            on_press: root.select_role('buyer')

<FarmerHomeScreen>:
    TabbedPanel:
        do_default_tab: False
        background_color: (0.9, 0.95, 0.9, 1)
        tab_pos: 'top_mid'
        
        TabbedPanelItem:
            text: 'My Products'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(10)
                spacing: dp(10)
                
                BoxLayout:
                    size_hint_y: None
                    height: dp(50)
                    spacing: dp(10)
                    
                    TextInput:
                        id: search_input
                        hint_text: 'Search your products...'
                        size_hint_x: 0.7
                        background_normal: ''
                        background_active: ''
                        background_color: (1, 1, 1, 1)
                        foreground_color: (0, 0, 0, 1)
                        padding: [dp(10), dp(15), dp(10), dp(5)]
                        multiline: False
                        on_text: root.search_products(self.text)
                    
                    CustomButton:
                        text: 'Add'
                        size_hint_x: 0.3
                        on_press: root.show_add_product_popup()
                
                ScrollView:
                    GridLayout:
                        id: products_grid
                        cols: 1
                        spacing: dp(10)
                        size_hint_y: None
                        height: self.minimum_height
                        padding: [dp(5), dp(5), dp(5), dp(5)]
        
        TabbedPanelItem:
            text: 'Orders'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(10)
                
                Label:
                    text: 'Recent Orders'
                    font_size: sp(20)
                    bold: True
                    size_hint_y: None
                    height: dp(40)
                    color: (0.2, 0.4, 0.2, 1)
                
                ScrollView:
                    GridLayout:
                        id: orders_grid
                        cols: 1
                        spacing: dp(10)
                        size_hint_y: None
                        height: self.minimum_height
                        padding: [dp(5), dp(5), dp(5), dp(5)]
        
        TabbedPanelItem:
            text: 'Profile'
            ScrollView:
                BoxLayout:
                    orientation: 'vertical'
                    padding: dp(20)
                    spacing: dp(20)
                    size_hint_y: None
                    height: dp(700)
                    
                    BoxLayout:
                        size_hint_y: None
                        height: dp(120)
                        spacing: dp(20)
                        
                        Image:
                            id: profile_img
                            source: root.profile_image
                            size_hint: None, None
                            size: dp(100), dp(100)
                            allow_stretch: True
                        
                        Button:
                            text: 'Change Photo'
                            size_hint_x: 0.6
                            background_normal: ''
                            background_color: (0.8, 0.8, 0.8, 0.5)
                            on_press: root.show_image_chooser()
                    
                    Label:
                        text: 'Account Settings'
                        font_size: sp(20)
                        bold: True
                        size_hint_y: None
                        height: dp(40)
                        color: (0.2, 0.4, 0.2, 1)
                    
                    BoxLayout:
                        orientation: 'vertical'
                        spacing: dp(10)
                        size_hint_y: None
                        height: dp(200)
                        
                        TextInput:
                            id: username_input
                            hint_text: 'Username'
                            text: root.username
                            background_normal: ''
                            background_color: (1, 1, 1, 1)
                            padding: [dp(10), dp(15), dp(10), dp(5)]
                            multiline: False
                        
                        TextInput:
                            id: location_input
                            hint_text: 'Location'
                            text: root.location
                            background_normal: ''
                            background_color: (1, 1, 1, 1)
                            padding: [dp(10), dp(15), dp(10), dp(5)]
                            multiline: False
                        
                        CustomButton:
                            text: 'Save Changes'
                            size_hint_y: None
                            height: dp(50)
                            on_press: root.save_profile_changes()
                    
                    Label:
                        text: 'App Settings'
                        font_size: sp(20)
                        bold: True
                        size_hint_y: None
                        height: dp(40)
                        color: (0.2, 0.4, 0.2, 1)
                    
                    BoxLayout:
                        orientation: 'vertical'
                        spacing: dp(10)
                        size_hint_y: None
                        height: dp(120)
                        
                        BoxLayout:
                            size_hint_y: None
                            height: dp(50)
                            spacing: dp(10)
                            
                            Label:
                                text: 'Dark Mode'
                                font_size: sp(18)
                                color: (0.2, 0.2, 0.2, 1)
                                size_hint_x: 0.7
                                halign: 'left'
                                text_size: self.width, None
                            
                            Switch:
                                id: dark_mode_switch
                                active: root.dark_mode
                                on_active: root.toggle_dark_mode(self.active)
                        
                        CustomButton:
                            text: 'Logout'
                            size_hint_y: None
                            height: dp(50)
                            background_color: (0.8, 0.2, 0.2, 1)
                            on_press: root.logout()

<BuyerHomeScreen>:
    TabbedPanel:
        do_default_tab: False
        background_color: (0.9, 0.95, 0.9, 1)
        tab_pos: 'top_mid'
        
        TabbedPanelItem:
            text: 'Products'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(10)
                spacing: dp(10)
                
                BoxLayout:
                    size_hint_y: None
                    height: dp(50)
                    
                    TextInput:
                        id: search_input
                        hint_text: 'Search for fresh produce...'
                        background_normal: ''
                        background_active: ''
                        background_color: (1, 1, 1, 1)
                        foreground_color: (0, 0, 0, 1)
                        padding: [dp(10), dp(15), dp(10), dp(5)]
                        multiline: False
                        on_text: root.search_products(self.text)
                
                ScrollView:
                    GridLayout:
                        id: products_grid
                        cols: 2
                        spacing: dp(10)
                        size_hint_y: None
                        height: self.minimum_height
                        padding: [dp(5), dp(5), dp(5), dp(5)]
        
        TabbedPanelItem:
            text: 'My Orders'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(10)
                
                Label:
                    text: 'Your Orders'
                    font_size: sp(20)
                    bold: True
                    size_hint_y: None
                    height: dp(40)
                    color: (0.2, 0.4, 0.2, 1)
                
                ScrollView:
                    GridLayout:
                        id: orders_grid
                        cols: 1
                        spacing: dp(10)
                        size_hint_y: None
                        height: self.minimum_height
                        padding: [dp(5), dp(5), dp(5), dp(5)]
        
        TabbedPanelItem:
            text: 'Profile'
            # Similar to farmer profile but without product management

<ProductItem@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: dp(150)
    padding: dp(5)
    spacing: dp(5)
    
    canvas.before:
        Color:
            rgba: (0.95, 0.98, 0.95, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10),]
    
    Image:
        source: root.product_image
        size_hint_y: None
        height: dp(100)
        allow_stretch: True
    
    Label:
        text: root.product_name
        font_size: sp(14)
        bold: True
        size_hint_y: None
        height: dp(20)
        text_size: self.width, None
        halign: 'center'
        color: (0.2, 0.2, 0.2, 1)
    
    Label:
        text: root.product_price
        font_size: sp(12)
        size_hint_y: None
        height: dp(20)
        text_size: self.width, None
        halign: 'center'
        color: (0.3, 0.5, 0.3, 1)

<OrderItem@BoxLayout>:
    orientation: 'horizontal'
    size_hint_y: None
    height: dp(100)
    padding: dp(10)
    spacing: dp(10)
    
    canvas.before:
        Color:
            rgba: (0.95, 0.98, 0.95, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10),]
    
    Image:
        source: root.order_image
        size_hint_x: None
        width: dp(80)
        allow_stretch: True
    
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(5)
        
        Label:
            text: root.order_product
            font_size: sp(16)
            bold: True
            text_size: self.width, None
            halign: 'left'
            color: (0.2, 0.2, 0.2, 1)
        
        Label:
            text: root.order_buyer
            font_size: sp(14)
            text_size: self.width, None
            halign: 'left'
            color: (0.4, 0.4, 0.4, 1)
        
        Label:
            text: root.order_status
            font_size: sp(14)
            text_size: self.width, None
            halign: 'left'
            color: (0.3, 0.5, 0.3, 1)

<AddProductPopup>:
    title: 'Add New Product'
    size_hint: 0.9, 0.8
    
    BoxLayout:
        orientation: 'vertical'
        padding: dp(20)
        spacing: dp(15)
        
        TextInput:
            id: product_name
            hint_text: 'Product Name'
            size_hint_y: None
            height: dp(50)
            background_normal: ''
            background_color: (1, 1, 1, 1)
            padding: [dp(10), dp(15), dp(10), dp(5)]
        
        TextInput:
            id: product_category
            hint_text: 'Category (e.g., Vegetables, Fruits)'
            size_hint_y: None
            height: dp(50)
            background_normal: ''
            background_color: (1, 1, 1, 1)
            padding: [dp(10), dp(15), dp(10), dp(5)]
        
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            spacing: dp(10)
            
            TextInput:
                id: product_quantity
                hint_text: 'Quantity'
                size_hint_x: 0.5
                background_normal: ''
                background_color: (1, 1, 1, 1)
                padding: [dp(10), dp(15), dp(10), dp(5)]
                input_filter: 'int'
            
            TextInput:
                id: product_price
                hint_text: 'Price (₹)'
                size_hint_x: 0.5
                background_normal: ''
                background_color: (1, 1, 1, 1)
                padding: [dp(10), dp(15), dp(10), dp(5)]
                input_filter: 'float'
        
        TextInput:
            id: product_description
            hint_text: 'Description'
            size_hint_y: None
            height: dp(100)
            background_normal: ''
            background_color: (1, 1, 1, 1)
            padding: [dp(10), dp(15), dp(10), dp(5)]
        
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            spacing: dp(10)
            
            Button:
                text: 'Add Image'
                size_hint_x: 0.5
                background_normal: ''
                background_color: (0.8, 0.8, 0.8, 0.5)
                on_press: root.choose_image()
            
            Image:
                id: product_image_preview
                size_hint_x: 0.5
                source: ''
                allow_stretch: True
        
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            spacing: dp(10)
            
            CustomButton:
                text: 'Cancel'
                on_press: root.dismiss()
            
            CustomButton:
                text: 'Add Product'
                on_press: root.add_product()

<ImageChooserPopup>:
    title: 'Choose Profile Image'
    size_hint: 0.9, 0.8
    
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(10)
        
        FileChooserIconView:
            id: file_chooser
            filters: ['*.png', '*.jpg', '*.jpeg']
        
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            spacing: dp(10)
            
            CustomButton:
                text: 'Cancel'
                on_press: root.dismiss()
            
            CustomButton:
                text: 'Select'
                on_press: root.select_image(file_chooser.selection)
''')

class RoleSelectionScreen(Screen):
    def select_role(self, role):
        if role == 'farmer':
            self.manager.current = 'farmer_home'
            self.manager.transition = SlideTransition(direction='left')
        else:
            self.manager.current = 'buyer_home'
            self.manager.transition = SlideTransition(direction='left')

class FarmerHomeScreen(Screen):
    profile_image = StringProperty('images/profiles/rajesh_kumar.png')
    username = StringProperty('Rajesh Kumar')
    location = StringProperty('Punjab, India')
    dark_mode = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super(FarmerHomeScreen, self).__init__(**kwargs)
        self.sample_products = [
            {
                'name': 'Organic Tomatoes', 
                'image': 'images/products/organic_tomatoes.png',
                'price': '₹50/kg',
                'quantity': '100 kg',
                'category': 'Vegetables'
            },
            {
                'name': 'Fresh Carrots', 
                'image': 'images/products/fresh_carrots.png',
                'price': '₹40/kg',
                'quantity': '80 kg',
                'category': 'Vegetables'
            },
            {
                'name': 'Wheat Grains', 
                'image': 'images/products/wheat_grains.png',
                'price': '₹30/kg',
                'quantity': '500 kg',
                'category': 'Grains'
            },
            {
                'name': 'Basmati Rice', 
                'image': 'images/products/basmati_rice.png',
                'price': '₹80/kg',
                'quantity': '300 kg',
                'category': 'Grains'
            },
            {
                'name': 'Apples', 
                'image': 'images/products/apples.png',
                'price': '₹120/kg',
                'quantity': '50 kg',
                'category': 'Fruits'
            }
        ]
        
        self.orders = [
            {
                'product': 'Organic Tomatoes',
                'image': 'images/products/organic_tomatoes.png',
                'buyer': 'Priya Sharma',
                'quantity': '20 kg',
                'price': '₹1000',
                'status': 'Delivered'
            },
            {
                'product': 'Fresh Carrots',
                'image': 'images/products/fresh_carrots.png',
                'buyer': 'Vikram Singh',
                'quantity': '15 kg',
                'price': '₹600',
                'status': 'In Transit'
            },
            {
                'product': 'Basmati Rice',
                'image': 'images/products/basmati_rice.png',
                'buyer': 'Anjali Patel',
                'quantity': '50 kg',
                'price': '₹4000',
                'status': 'Pending'
            }
        ]
    
    def on_enter(self):
        self.load_products()
        self.load_orders()
    
    def load_products(self):
        products_grid = self.ids.products_grid
        products_grid.clear_widgets()
        
        for product in self.sample_products:
            item = Builder.template(
                'ProductItem', 
                product_name=product['name'],
                product_image=product['image'],
                product_price=product['price']
            )
            products_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)
    
    def load_orders(self):
        orders_grid = self.ids.orders_grid
        orders_grid.clear_widgets()
        
        for order in self.orders:
            item = Builder.template(
                'OrderItem',
                order_product=order['product'],
                order_image=order['image'],
                order_buyer=f"Buyer: {order['buyer']}",
                order_status=f"Status: {order['status']}",
                order_quantity=f"Qty: {order['quantity']}",
                order_price=f"Total: {order['price']}"
            )
            orders_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)
    
    def search_products(self, query):
        products_grid = self.ids.products_grid
        products_grid.clear_widgets()
        
        if not query:
            self.load_products()
            return
            
        filtered_products = [p for p in self.sample_products if query.lower() in p['name'].lower()]
        
        for product in filtered_products:
            item = Builder.template(
                'ProductItem', 
                product_name=product['name'],
                product_image=product['image'],
                product_price=product['price']
            )
            products_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)
    
    def show_add_product_popup(self):
        popup = AddProductPopup()
        popup.bind(on_dismiss=self.load_products)
        popup.open()
    
    def show_image_chooser(self):
        popup = ImageChooserPopup()
        popup.bind(on_dismiss=self.update_profile_image)
        popup.open()
    
    def update_profile_image(self, instance):
        if hasattr(instance, 'selected_image'):
            self.profile_image = instance.selected_image
    
    def save_profile_changes(self):
        self.username = self.ids.username_input.text
        self.location = self.ids.location_input.text
        # Show confirmation
        self.show_toast("Profile updated successfully!")
    
    def toggle_dark_mode(self, active):
        self.dark_mode = active
        theme = "Dark" if active else "Light"
        self.show_toast(f"{theme} mode enabled")
    
    def logout(self):
        self.manager.current = 'role_selection'
        self.manager.transition = SlideTransition(direction='right')
    
    def show_toast(self, message):
        toast = Label(text=message, size_hint_y=None, height=dp(40), 
                      color=(1, 1, 1, 1), bold=True)
        toast_layout = FloatLayout()
        toast_layout.add_widget(toast)
        
        popup = Popup(title='', content=toast_layout, size_hint=(0.8, None), height=dp(50),
                      background_color=(0.2, 0.7, 0.3, 0.9), separator_height=0)
        popup.open()
        
        Clock.schedule_once(lambda dt: popup.dismiss(), 2)

class BuyerHomeScreen(Screen):
    def __init__(self, **kwargs):
        super(BuyerHomeScreen, self).__init__(**kwargs)
        self.all_products = [
            {
                'name': 'Organic Tomatoes', 
                'image': 'images/products/organic_tomatoes.png',
                'price': '₹50/kg',
                'farmer': 'Rajesh Kumar'
            },
            {
                'name': 'Fresh Carrots', 
                'image': 'images/products/fresh_carrots.png',
                'price': '₹40/kg',
                'farmer': 'Rajesh Kumar'
            },
            {
                'name': 'Wheat Grains', 
                'image': 'images/products/wheat_grains.png',
                'price': '₹30/kg',
                'farmer': 'Vikram Singh'
            },
            {
                'name': 'Basmati Rice', 
                'image': 'images/products/basmati_rice.png',
                'price': '₹80/kg',
                'farmer': 'Anjali Patel'
            },
            {
                'name': 'Apples', 
                'image': 'images/products/apples.png',
                'price': '₹120/kg',
                'farmer': 'Priya Sharma'
            },
            {
                'name': 'Mangoes', 
                'image': 'images/products/mangoes.png',
                'price': '₹80/kg',
                'farmer': 'Priya Sharma'
            },
            {
                'name': 'Potatoes', 
                'image': 'images/products/potatoes.png',
                'price': '₹35/kg',
                'farmer': 'Vikram Singh'
            },
            {
                'name': 'Onions', 
                'image': 'images/products/onions.png',
                'price': '₹45/kg',
                'farmer': 'Anjali Patel'
            }
        ]
        
        self.orders = [
            {
                'product': 'Organic Tomatoes',
                'image': 'images/products/organic_tomatoes.png',
                'farmer': 'Rajesh Kumar',
                'quantity': '5 kg',
                'price': '₹250',
                'status': 'Delivered'
            },
            {
                'product': 'Basmati Rice',
                'image': 'images/products/basmati_rice.png',
                'farmer': 'Anjali Patel',
                'quantity': '10 kg',
                'price': '₹800',
                'status': 'In Transit'
            }
        ]
    
    def on_enter(self):
        self.load_products()
        self.load_orders()
    
    def load_products(self):
        products_grid = self.ids.products_grid
        products_grid.clear_widgets()
        
        for product in self.all_products:
            item = Builder.template(
                'ProductItem', 
                product_name=product['name'],
                product_image=product['image'],
                product_price=product['price']
            )
            products_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)
    
    def load_orders(self):
        orders_grid = self.ids.orders_grid
        orders_grid.clear_widgets()
        
        for order in self.orders:
            item = Builder.template(
                'OrderItem',
                order_product=order['product'],
                order_image=order['image'],
                order_buyer=f"Farmer: {order['farmer']}",
                order_status=f"Status: {order['status']}",
                order_quantity=f"Qty: {order['quantity']}",
                order_price=f"Total: {order['price']}"
            )
            orders_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)
    
    def search_products(self, query):
        products_grid = self.ids.products_grid
        products_grid.clear_widgets()
        
        if not query:
            self.load_products()
            return
            
        filtered_products = [p for p in self.all_products if query.lower() in p['name'].lower()]
        
        for product in filtered_products:
            item = Builder.template(
                'ProductItem', 
                product_name=product['name'],
                product_image=product['image'],
                product_price=product['price']
            )
            products_grid.add_widget(item)
            
            # Add animation
            anim = Animation(opacity=1, duration=0.5)
            anim.start(item)

class AddProductPopup(Popup):
    def choose_image(self):
        popup = ImageChooserPopup()
        popup.bind(on_dismiss=self.update_image_preview)
        popup.open()
    
    def update_image_preview(self, instance):
        if hasattr(instance, 'selected_image'):
            self.ids.product_image_preview.source = instance.selected_image
    
    def add_product(self):
        # In a real app, you would save the product to a database
        self.dismiss()
        # Show confirmation
        self.show_toast("Product added successfully!")
    
    def show_toast(self, message):
        toast = Label(text=message, size_hint_y=None, height=dp(40), 
                      color=(1, 1, 1, 1), bold=True)
        toast_layout = FloatLayout()
        toast_layout.add_widget(toast)
        
        popup = Popup(title='', content=toast_layout, size_hint=(0.8, None), height=dp(50),
                      background_color=(0.2, 0.7, 0.3, 0.9), separator_height=0)
        popup.open()
        
        Clock.schedule_once(lambda dt: popup.dismiss(), 2)

class ImageChooserPopup(Popup):
    def select_image(self, selection):
        if selection:
            self.selected_image = selection[0]
        self.dismiss()

class HTFApp(App):
    def build(self):
        self.title = "Help The Farmers"
        self.icon = 'data/logo.png'  # Replace with your logo
        
        sm = ScreenManager()
        sm.add_widget(RoleSelectionScreen(name='role_selection'))
        sm.add_widget(FarmerHomeScreen(name='farmer_home'))
        sm.add_widget(BuyerHomeScreen(name='buyer_home'))
        return sm

if __name__ == '__main__':
    HTFApp().run()
